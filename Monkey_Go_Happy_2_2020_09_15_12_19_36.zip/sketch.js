var stone, stone_animation;
var monkey, monkey_animation;
var jungle, jungle_animation;
var banana, banana_animation;
var invisibleGround;

var count;

var foodGroup = createGroup();
var stoneGroup = createGroup();

function preload() {
   stone_animation = loadImage("stone.png");
  
   monkey_animation = loadImage("Monkey_01.png, Monkey_02.png, Monkey_03.png,                Monkey_04.png, Monkey_05.png, Monkey_06.png, Monkey_07.png, Monkey_08.png,                Monkey_09.png, Monkey_10.png");
  
   jungle_animation = loadImage("jungle.jpg");
  
   banana_animation = loadImage("banana.png");
}


function setup() {
  createCanvas(400, 400);
  stone.addImage("stone_tab" , stone_animation)
  
  monkey = createSprite (70,300);
  monkey.addImage("Monkey_tab" , monkey_animation)
  
  jungle = createSprite (50,200);
  jungle.addImage("jungle_tab" , jungle_animation)
  jungle.velocityX = -4;
  jungle.scale = 1.5;
  
  banana.addImage("banana_tab" , banana_animation)
  
  invisibleGround = createSprite(200,385,400,5);
  invisibleGround.visible = false;
}


function draw() {
  background("white");
  
  jungle.velocityX = -6;
  
  if(jungle.x < 0) {
   jungle.x = invisibleGround.width/2;
  }
  
  drawSprites();
  
  text("Score: "+ count, 250, 100);
}

function spawnbananas() {
 if (World.frameCount%80 === 0){
  var banana = createSprite(400, 230);
  banana.y = randomNumber(200,290);
  banana.lifetime = 105;
  banana.velocityX = -4;
  foodGroup.add(banana);
 }
}

function spawnRocks() {
 if (World.frameCount%300 === 0){
  var Rocks = createSprite(400, 230);
  Rocks.y = 365;
  Rocks.lifetime = 105;
  Rocks.velocityX = -4;
  stoneGroup.add(stone);
 }
}